package com.cw.board.movie;

import com.cw.board.main.DBManager;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class MovieDAO {
    //전제조회하는 기능



    public static final MovieDAO MDAO = new MovieDAO();
    private MovieDAO(){} ;




    private  ArrayList<MovieDTO> movies;


    public void selectAllMovie(HttpServletRequest request) {
        //1. 값 or db
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from movie_test";
        try {

            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();


            MovieDTO dto = null;
            movies = new ArrayList<>();
            while (rs.next()) {
                dto = new MovieDTO();
                dto.setNo(rs.getInt("m_no"));
                dto.setTitle(rs.getString("m_title"));
                dto.setActor(rs.getString("m_actor"));
                dto.setImg(rs.getString("m_img"));
                dto.setStory(rs.getString("m_story"));

                movies.add(dto);
            }
            request.setAttribute("movies", movies);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, rs);
        }


    }


    public void addMovie(HttpServletRequest req) {


        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "insert into movie_test values (movie_test_seq.nextval,?,?,?,?)";
        // String path = req.getSession().getServletContext().getRealPath("movieFile");
        String path = "C:\\es\\dbws.intellij\\upload\\movieFile";
        System.out.println(path);

        try {

            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);

            MultipartRequest mr = new MultipartRequest(req, path, 1024 * 1024 * 20, "UTF-8", new DefaultFileRenamePolicy());
            String title = mr.getParameter("title");
            String actor = mr.getParameter("actor");
            String story = mr.getParameter("story");
            String fileName = mr.getFilesystemName("file");


            System.out.println(title);
            System.out.println(actor);
            System.out.println(story);
            System.out.println(fileName);


            story = story.replaceAll("\r\n", "<br>");

            pstmt.setString(1, title);
            pstmt.setString(2, actor);
            pstmt.setString(3, fileName);
            pstmt.setString(4, story);
            if (pstmt.executeUpdate() == 1) {
                System.out.println("good");
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, null);
        }


    }

    public void delete(HttpServletRequest request) {

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "delete movie_test where m_no=?";

        try {

            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, request.getParameter("no"));
            if (pstmt.executeUpdate() == 1) {
                System.out.println("deleted");
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, null);
        }
    }

    public void getMovie(HttpServletRequest request) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from movie_test where m_no=?";
        try {

            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, request.getParameter("no"));
            rs = pstmt.executeQuery();


            MovieDTO dto = null;
            if (rs.next()) {

                dto = new MovieDTO();
                dto.setNo(rs.getInt("m_no"));
                dto.setTitle(rs.getString("m_title"));
                dto.setActor(rs.getString("m_actor"));
                dto.setImg(rs.getString("m_img"));
                dto.setStory(rs.getString("m_story"));
            }
            System.out.println(dto);
            request.setAttribute("movie", dto);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, rs);
        }


    }

    public void upMovie(HttpServletRequest req) {

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "update movie_test set m_title=?,m_actor=?,m_story=? where m_no=?";

        try {

            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            String title = req.getParameter("title");
            String actor = req.getParameter("actor");
            String story = req.getParameter("story");
            String no = req.getParameter("no");

            story = story.replaceAll("\r\n", "<br>");
            System.out.println(title);
            System.out.println(actor);
            System.out.println(story);
            System.out.println(no);
            pstmt.setString(1, title);
            pstmt.setString(2, actor);
            pstmt.setString(3, story);
            pstmt.setString(4, no);

            if (pstmt.executeUpdate() == 1) {
                System.out.println("updated");
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, null);
        }


    }

    public void upMovie2(HttpServletRequest req) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "update movie_test set  m_title=?,m_actor=?,m_img=?,m_story=? where m_no=?";
        // String path = req.getSession().getServletContext().getRealPath("movieFile");
        String path = "C:\\es\\dbws.intellij\\upload\\movieFile";
        System.out.println(path);

        try {

            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);

            MultipartRequest mr = new MultipartRequest(req, path, 1024 * 1024 * 20, "UTF-8", new DefaultFileRenamePolicy());

            String title = mr.getParameter("title");
            String actor = mr.getParameter("actor");
            String story = mr.getParameter("story");
            String newImg = mr.getFilesystemName("newImg");
            String img = newImg;
            String oldImg = mr.getParameter("oldImg");
            String no = mr.getParameter("no");
            if (newImg == null) {
                img = oldImg;
            }

            System.out.println(title);
            System.out.println(actor);
            System.out.println(story);
            //System.out.println(fileName);


            story = story.replaceAll("\r\n", "<br>");

            pstmt.setString(1, title);
            pstmt.setString(2, actor);
            pstmt.setString(3, img);
            pstmt.setString(4, story);
            pstmt.setString(5, no);

            req.setAttribute("noo", no);
            if (pstmt.executeUpdate() == 1) {
                System.out.println("good");
                if (newImg != null) {//전에 사진교체
                    File f = new File(path + "/" + oldImg);
                    f.delete();
                }
            }
            //멀티포장에서 req를 사용하려고 셋을사용

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, null);//같은 리퀘스트임
        }


    }

    public void paging(int pageNum, HttpServletRequest req) {

        int total = movies.size();
        int cnt = 3;
        req.setAttribute("pageNum", pageNum);
        // 페이지 수
        int totalPage = (int) Math.ceil((double) total / cnt);

        int start = total - (cnt * (pageNum - 1));
        int end = (pageNum == totalPage) ? -1 : start - (cnt + 1);

        ArrayList<MovieDTO> items = new ArrayList<>();
        for (int i = start - 1; i > end; i--) {
            items.add(movies.get(i));
            // selcetAll에서 쓴 movies 배열을 그대로 사용하고 싶다 하면!!
            // 전혁변수 사용하기
            // 바깥에 만들어져 있는 것!


        }
        req.setAttribute("totalPage", totalPage);

        req.setAttribute("movies", items);

    }

}
