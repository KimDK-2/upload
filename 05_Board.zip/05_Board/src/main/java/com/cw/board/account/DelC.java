package com.cw.board.account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/del-user")
public class DelC extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //삭제시키는일
        AccountDAO.ADAO.deleteUser(request);

        response.sendRedirect("index.jsp");




    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

     if(   AccountDAO.ADAO.deleteUser(request)){

response.sendRedirect("user-info");
     }else {
         response.sendRedirect("user-info");
     }
    }
    public void destroy() {
    }


}