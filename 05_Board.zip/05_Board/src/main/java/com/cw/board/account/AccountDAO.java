package com.cw.board.account;

import com.cw.board.main.DBManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AccountDAO {
    public static final AccountDAO ADAO = new AccountDAO();

    private AccountDAO() {

    }


    public boolean loginCheck(HttpServletRequest req) {
        AccountVO user = (AccountVO) req.getSession().getAttribute("user");
        if (user != null) {
            req.setAttribute("loginPage", "jsp/account/loginOK.jsp");
            return true;
        } else {
            req.setAttribute("loginPage", "jsp/account/login.jsp");
            return false;
        }

    }

    public void AccountDAO(HttpServletRequest request) {
        String id = request.getParameter("id");
        String pw = request.getParameter("pw");
        if (id == null) {
            id = (String) request.getAttribute("iddd");
        }
        //db여기에 있는 계정이랑 비교
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from login_test where l_id=?";
        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, id);
            rs = pstmt.executeQuery();
            String msg = "";
            if (rs.next()) {
                if (rs.getString("l_pw").equals(pw)) {
                    //성공존
                    System.out.println("로그인성공");
                    msg = "로그인성공";
                } else {
                    System.out.println("비번오류");
                    //비번오류
                    msg = "비번오류";
                }
            } else {
                System.out.println("아이디없음");
                //id없음
                msg = "아이디없음";
            }
            request.setAttribute("msg", msg);
            AccountVO accountVO = new AccountVO();
            accountVO.setId(rs.getString("l_id"));
            accountVO.setPw(rs.getString("l_pw"));
            accountVO.setName(rs.getString("l_name"));
            //  request.setAttribute("user",accountVO);
            HttpSession hs = request.getSession();
            hs.setAttribute("user", accountVO);
            hs.setMaxInactiveInterval(300);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, rs);

        }


    }


    public void logout(HttpServletRequest request) {
        HttpSession hs = request.getSession();
        hs.removeAttribute("user");
        //  hs.invalidate();
//    hs.setAttribute("user",null);

    }

    public boolean deleteUser(HttpServletRequest request) {
        String id = request.getParameter("id");


        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "delete login_test where l_id=?";
        AccountVO user = (AccountVO) request.getSession().getAttribute("user");
        try {
            if (user.getPw().equals(request.getParameter("pw"))) {
                con = DBManager.connect();
                pstmt = con.prepareStatement(sql);
                pstmt.setString(1, user.getId());

                if (pstmt.executeUpdate() == 1) {
                    System.out.println("deleted");
                    logout(request);
                    return true;
                }

                //  request.setAttribute("user",accountVO);
            } else return false;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, null);

        }
        return false;
    }

    public void editUser(HttpServletRequest request) {


        Connection con = null;
        PreparedStatement pstmt = null;
        String sql = "update login_test set l_pw=?,l_name=? where l_id=?";
        AccountVO user = (AccountVO) request.getSession().getAttribute("user");
        try {
            con = DBManager.connect();
            pstmt = con.prepareStatement(sql);
            String changeName = request.getParameter("name");
            String changePw = request.getParameter("pw");
            pstmt.setString(1, changePw);
            pstmt.setString(2, changeName);
            pstmt.setString(3, user.getId());


            if (pstmt.executeUpdate() == 1) {
                System.out.println("updated");
                //request.setAttribute("iddd",user.getId());
                //로그인다시 세션값을 다시 바꿔야하니까

                //AccountDAO(request);
                //세션을 업데이트
                user.setName(changeName);
                user.setPw(changePw);
            }

            //  request.setAttribute("user",accountVO);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(con, pstmt, null);

        }
    }
}
