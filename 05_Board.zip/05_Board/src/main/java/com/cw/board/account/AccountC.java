package com.cw.board.account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AccountC", value = "/user-login")
public class AccountC extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //로그아웃하는일
        AccountDAO.ADAO.logout(request);
        response.sendRedirect("hello-servlet");


    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AccountDAO.ADAO.AccountDAO(request);

        AccountDAO.ADAO.loginCheck(request);
        request.setAttribute("content","home.jsp");
        request.getRequestDispatcher("index.jsp").forward(request,response);

    }
    public void destroy() {
    }
}