package com.cw.board.review;

import com.cw.board.main.DBManager;

import javax.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;

public class ReviewDAO2 {

    public static final ReviewDAO2 RDAO = new ReviewDAO2();

    private ReviewDAO2() {
    }

    public ArrayList<ReviewVO> showAllReview(HttpServletRequest request) {

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from review_test order by r_date";
        try {
            conn = DBManager.connect();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            ReviewVO reviewVO = null;
            ArrayList<ReviewVO> reviews = new ArrayList<>();
            while (rs.next()) {
                int no = rs.getInt("r_no");
                String title = rs.getString("r_title");
                String txt = rs.getString("r_txt");
                Date date= rs.getDate("r_date");
                reviewVO = new ReviewVO();
                reviewVO.setNo(no);
                reviewVO.setTitle(title);
                reviewVO.setTxt(txt);
                reviewVO.setDate(date);
                reviews.add(reviewVO);
            }
            return reviews;
//            request.setAttribute("reviews", reviews);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(conn,pstmt,rs);
        }


        return null;
    }

    public void addReview(HttpServletRequest req) {
            // 1. 값 or db
        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "insert into review_test values (" +
                "review_test_seq.nextval, ?, ?, sysdate)";
        try {
            conn = DBManager.connect();
            pstmt = conn.prepareStatement(sql);
            req.setCharacterEncoding("UTF-8");
            pstmt.setString(1, req.getParameter("title"));
            pstmt.setString(2, req.getParameter("txt"));

            if(pstmt.executeUpdate() == 1){
                System.out.println("add review success");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn,pstmt,null);
        }



    }

    public void getRview(HttpServletRequest request) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select * from review_test where r_no = ?";
        try {
            conn = DBManager.connect();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,request.getParameter("pk"));
            rs = pstmt.executeQuery();
            ReviewVO reviewVO = null;
            if (rs.next()) {
                int no = rs.getInt("r_no");
                String title = rs.getString("r_title");
                String txt = rs.getString("r_txt");
                Date date= rs.getDate("r_date");
                reviewVO = new ReviewVO();
                reviewVO.setNo(no);
                reviewVO.setTitle(title);
                reviewVO.setTxt(txt);
                reviewVO.setDate(date);
            }
            request.setAttribute("review", reviewVO);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            DBManager.close(conn,pstmt,rs);
        }
    }

    public void updateRview(HttpServletRequest request) {


        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "update review_test set r_title=?, r_txt=? where r_no=?";
        try {
            conn = DBManager.connect();
            pstmt = conn.prepareStatement(sql);
            request.setCharacterEncoding("UTF-8");
            pstmt.setString(1, request.getParameter("title"));
            pstmt.setString(2, request.getParameter("txt"));
            pstmt.setString(3, request.getParameter("no"));
            if(pstmt.executeUpdate() == 1){
                System.out.println("update review success");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn,pstmt,null);
        }


    }

    public void delReview(HttpServletRequest request) {


        Connection conn = null;
        PreparedStatement pstmt = null;

        String sql = "delete from review_test where r_no=?";
        try {
            conn = DBManager.connect();
            pstmt = conn.prepareStatement(sql);
            request.setCharacterEncoding("UTF-8");
            pstmt.setString(1, request.getParameter("no"));
            if(pstmt.executeUpdate() == 1){
                System.out.println("delete review success");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBManager.close(conn,pstmt,null);
        }
    }
    public void paging(int pageNum, HttpServletRequest req) {
        req.setAttribute("currentPage", pageNum);
        ArrayList<ReviewVO> reviews = RDAO.showAllReview(req);
        int total = reviews.size();
        int cnt = 3;

        // 페이지수
        int totalPage = (int) Math.ceil((double) total / cnt);
        req.setAttribute("totalPage", totalPage);

        int start = total - (cnt * (pageNum - 1));
        int end = (pageNum == totalPage) ? -1 : start - (cnt + 1);

        ArrayList<ReviewVO> items = new ArrayList<>();
        for (int i = start - 1; i > end; i--) {
            items.add(reviews.get(i));
        }

        req.setAttribute("reviews", items);


    }
}
