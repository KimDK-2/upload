package com.cw.board.account;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AccountInfoC", value = "/user-info")
public class AccountInfoC extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //id조회는 이미 세션에서 끝남 기능사용만하면 편하지
        if(AccountDAO.ADAO.loginCheck(request)){

        request.setAttribute("content","jsp/account/mypage.jsp");
        }else {
            request.setAttribute("content","home.jsp");
        };
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AccountDAO.ADAO.AccountDAO(request);

        AccountDAO.ADAO.loginCheck(request);
        request.setAttribute("content","home.jsp");
        request.getRequestDispatcher("index.jsp").forward(request,response);

    }
    public void destroy() {
    }
}