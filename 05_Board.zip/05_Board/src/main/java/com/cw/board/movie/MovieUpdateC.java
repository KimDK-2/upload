package com.cw.board.movie;

import com.cw.board.account.AccountDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/edit")
public class MovieUpdateC extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        AccountDAO.ADAO.loginCheck(request);
        MovieDAO.MDAO.getMovie(request);
        request.setAttribute("content", "jsp/movie/movie_edit.jsp");
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //수정하는일
        AccountDAO.ADAO.loginCheck(req);
        MovieDAO.MDAO.upMovie2(req
        );


        //어디로?
        resp.sendRedirect("detail-movie?no="+req.getAttribute("noo"));//mr은 박포장이어서 풀어줘야해

    }

    public void destroy() {
    }
}