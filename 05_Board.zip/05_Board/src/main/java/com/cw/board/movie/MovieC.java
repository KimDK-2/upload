package com.cw.board.movie;

import com.cw.board.account.AccountDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "MovieC", value = "/movie")
public class MovieC extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        AccountDAO.ADAO.loginCheck(request);
        String p =request.getParameter("p");
        int page=1;
        if (p!=null){
            page=Integer.parseInt(p);

        }
        //MovieDAO.selectAllMovie(request);

        //ovieDAO.paging(page,request);
        MovieDAO.MDAO.selectAllMovie(request);
        MovieDAO.MDAO.paging(page,request);
       request.setAttribute("content","jsp/movie/movie.jsp");
        request.getRequestDispatcher("index.jsp").forward(request,response);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //등록하는일
        AccountDAO.ADAO.loginCheck(req);
        MovieDAO.MDAO.addMovie(req);
        //어디로?
        resp.sendRedirect("movie");

    }

    public void destroy() {
    }
}