create table movie_test
(
m_no number(3)primary key ,
m_title varchar2(30 char) not null ,
m_actor varchar2(30 char)not null ,
m_img varchar2(200 char)not null ,
m_story varchar2(500 char)not null

);
create sequence movie_test_seq;

insert into movie_test values (movie_test_seq.nextval,'매트릭스','키아누','a.jpg','가상세카이~');

insert into movie_test values (movie_test_seq.nextval,'기생충','송강호','parasite.jpg','전혀 다른 두 가족이 얽히며 벌어지는 블랙코미디 스릴러');

insert into movie_test values (movie_test_seq.nextval,'어벤져스','로버트 다우니 주니어','avengers.jpg','지구를 지키기 위해 히어로들이 힘을 합치는 액션 영화');

insert into movie_test values (movie_test_seq.nextval,'타이타닉','레오나르도 디카프리오','titanic.jpg','거대한 여객선에서 피어나는 비극적인 사랑 이야기');

insert into movie_test values (movie_test_seq.nextval,'라라랜드','라이언 고슬링','lalaland.jpg','꿈을 좇는 두 남녀의 사랑과 현실을 그린 뮤지컬 영화');

insert into movie_test values (movie_test_seq.nextval,'부산행','공유','busan.jpg','좀비 바이러스가 퍼진 열차 안에서 살아남기 위한 사투');

insert into movie_test values (movie_test_seq.nextval,'올드보이','최민식','oldboy.jpg','오랜 감금 끝에 풀려난 남자의 강렬한 복수극');

insert into movie_test values (movie_test_seq.nextval,'겨울왕국','크리스틴 벨','frozen.jpg','자매의 사랑과 모험을 담은 디즈니 애니메이션');

insert into movie_test values (movie_test_seq.nextval,'범죄도시','마동석','crimecity.jpg','강력반 형사가 조직폭력배를 소탕하는 통쾌한 액션 영화');

insert into movie_test values (movie_test_seq.nextval,'인셉션','레오나르도 디카프리오','inception.jpg','꿈속에 들어가 생각을 훔치거나 심는 미션을 그린 SF 스릴러');
select * from movie_test

