<%--
  Created by IntelliJ IDEA.
  User: soldesk
  Date: 2026-03-25
  Time: 오전 10:02
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<h1> -edit page- </h1>
<form action="user-edit" method="post">

<div class="info-wrap">

    <div class="info-row">

        <div>ID.</div>
        <div>${sessionScope.user.id}</div>
    </div>
    <div class="info-row">

        <div>PW.</div>
        <div > <input name="pw" type="text" value="${sessionScope.user.pw}"></div>
    </div>
    <div class="info-row">

        <div>NAME.</div>
        <div><input name="name" type="text" value="${sessionScope.user.name}"></div>
    </div>
    <div>
        <button class="movie-btn" onclick="">완료</button>
        <button type="button" class="movie-btn" onclick="history.back()"> 캰스루루루</button>




        </div>

    </div>
</div>
</form>

</body>
<script>
    function deleteUser() {

        //     let user = prompt("진짜? 그럼 비번입력해줘")
        //     if (user == pwpw) {
        //         location.href = 'del-user?id=' + idid;
        //     } else {
        //
        //     }
        // }
        document.querySelector('.confirm').style.display='block'}
</script>
</body>
</html>
