<%--
  Created by IntelliJ IDEA.
  User: soldesk
  Date: 2026-03-24
  Time: 오후 12:42
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<h1> 나야나~ </h1>

<div class="info-wrap">

    <div class="info-row">

        <div>ID.</div>
        <div>${sessionScope.user.id}</div>
    </div>
    <div class="info-row">

        <div>PW.</div>
        <div>${sessionScope.user.pw}</div>
    </div>
    <div class="info-row">

        <div>NAME.</div>
        <div>${sessionScope.user.name}</div>
    </div>
    <div>
        <button class="movie-btn" onclick="location.href='user-edit'">수정</button>
        <button class="movie-btn" onclick="deleteUser()"> 탈퇴</button>
        <div class="confirm" style="display: none">
            <form action="del-user" method="post">
                <input type="password" name="pw">
                <button class="movie-btn conf">confirm</button>
            </form>


        </div>

    </div>
</div>


</body>
<script>
    function deleteUser() {

    //     let user = prompt("진짜? 그럼 비번입력해줘")
    //     if (user == pwpw) {
    //         location.href = 'del-user?id=' + idid;
    //     } else {
    //
    //     }
     // }
                document.querySelector('.confirm').style.display='block'}
</script>
</html>
