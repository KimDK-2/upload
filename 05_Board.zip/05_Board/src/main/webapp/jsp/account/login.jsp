<%--
  Created by IntelliJ IDEA.
  User: soldesk
  Date: 2026-03-24
  Time: 오전 9:50
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<form action="user-login" method="post">
  <input type="text" name="id" placeholder="id"><br>
  <input type="text" name="pw" placeholder="pw"><br>
  <button>login</button>

</form>



</body>
</html>
