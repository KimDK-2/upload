<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%--
  Created by IntelliJ IDEA.
  User: soldesk
  Date: 2026-03-20
  Time: 오후 12:09
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>영황</title>

</head>
<body>

<div style="display: flex; justify-content: center;">
    <form action="movie" method="post" enctype="multipart/form-data">

        <div class="movie-reg">
            <div>
                <div>Title</div>
                <div>
                    <input name="title">
                </div>
            </div>
            <div>
                <div>Actor</div>
                <div>
                    <input name="actor">
                </div>
            </div>
            <div>
                <div>File</div>
                <div>
                    <input type="file" name="file">
                </div>
            </div>
            <div>
                <div>Story</div>
                <div>
                    <textarea rows="5" cols="40" name="story"></textarea>
                </div>
            </div>
            <div>
                <div>
                    <button class="movie-btn">Add</button>
                </div>
            </div>
        </div>
    </form>
</div>
<hr>
<div style="width: 100%; display: flex; justify-content: center;">
    <div class="movie-container">
        <c:forEach var="movie" items="${movies}">
            <div class="movie-wrap">
                <div class="movie-img" onclick="location.href='detail-movie?no='+${movie.no}">
                    <img alt="" src="/images/${movie.img}"><!-- 처음부터 인데스하면 자바실행 이말은 즉 위 폴더로올림 자바는 빌드부터실행임 밑에는 없어 걍 빌드만 실행-->
                </div>
                <div class="movie-title">${movie.title}</div>
                <div class="movie-actor">${movie.actor}</div>
                <div><button class="movie-btn" onclick="deleteMovie(${movie.no})">delete</button>
                    <button class="movie-btn"  onclick="location.href='update?no=${movie.no}'">수정(jsp)</button>
                    <button class="movie-btn" onclick="location.href='edit?no=${movie.no}'" >수정(img.jsp)</button>
                    <button class="movie-btn" >수정(js)</button>





                </div>
            </div>
        </c:forEach>
        <div>
            <c:choose>
                <c:when test="${pageNum!=1}">

                    <button class="movie-btn pn" onclick="location.href='movie?p=${pageNum-1}'">prev</button
                </c:when>
                <c:otherwise>

                    <button class="movie-btn pn shake">next</button>
                </c:otherwise>
            </c:choose>


            <c:choose>
                <c:when test="${pageNum!=totalpage}">

                <button class="movie-btn pn" onclick="location.href='movie?p=${pageNum+1}'">next</button
                </c:when>
                <c:otherwise>

            <button class="movie-btn pn shake">next</button>
                </c:otherwise>
            </c:choose>

        </div>
    </div>
</div>
<div>


    <a href="movie">[bigin]</a>
        <c:forEach begin="1" end="${totalPage}" var="i">

           <a href="movie?p=${i}"> [${i}]</a>

        </c:forEach>
    <a href="movie?${totalPage}">[end]</a>

</div>

</body>
<script>
    function deleteMovie(movieNo) {
       let ok =confirm('Are you sure you want to delete this movie?');
       if (ok){
           location.href='del?no='+movieNo;
       }

    }
</script>
</html>
