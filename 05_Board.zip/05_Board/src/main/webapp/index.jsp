<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP - Hello World</title>
    <link href="css/index.css" rel="stylesheet">
    <link href="css/movie.css" rel="stylesheet">
    <link href="css/review.css" rel="stylesheet">

</head>
<body>


<br/>
<a href="hello-servlet">Hello Servlet</a>

<div class="login-area">
    <span style="color: red">${msg}</span>
    <jsp:include page="${loginPage}"></jsp:include>

</div>





<div class="container">
    <div class="title">
        <a href="hello-servlet"> Cw's place </a>
    </div>
    <div class="menu">
        <div>
            <a href="menu1" >[Menu1]</a>
        </div>
        <div>
            <a href="movie">[Movie]</a>
        </div>
        <div>
            <a href="review"  >[Review]</a>
        </div>
    </div>
    <div class="content">
        <jsp:include page="${content }"></jsp:include>
    </div>
</div>
</body>
</html>